Attention please:
The results of this project include:
- a notebook file (imitation_ddpg_submission.ipynb)
- an environment file (Poppy_Env.py).
- a trained model file (ddpg_imitation.zip)
- a video for the trained robot (result video.mp4)
They are uploaded together in a packaged file.